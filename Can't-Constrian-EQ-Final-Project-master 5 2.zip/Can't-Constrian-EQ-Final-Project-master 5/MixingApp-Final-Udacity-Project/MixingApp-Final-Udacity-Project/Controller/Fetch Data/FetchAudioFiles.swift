//
//  FetchAudioFiles.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-26.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import Firebase
import AVFoundation
import UIKit

extension TracksViewController {
    
    //MARK: FETCH AUDIO FILE
    
    func fetchAudioFile(indexPath: IndexPath) {
        let storageRef = Storage.storage().reference().child(self.userID!).child(self.projectKey!).child("audiofiles").child("track\(indexPath.row)").child("audio\(indexPath.row).mp3")
        let fileManager = FileManager.default //reference to file system contents
        storageRef.downloadURL { (url, error) in //download url from firebase
            if error != nil {
                self.uploadingAudioLabel.text = "No Audio in track \(indexPath.row)"
                return
            }
            
            if let url = url {
                
                if let documentDirectory = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) {
                    
                    let filePath = documentDirectory.appendingPathComponent(url.lastPathComponent) //ref to local storage
                    print("URL: \(url)")
                    
                    guard let audioFileData = try? Data(contentsOf: url) else { return }
                    
                    try? audioFileData.write(to: filePath) //save audio to local storage
                    
                    print("FILE PATH: \(filePath)")
                    print("AUDIO FILE DATA: \(audioFileData)")
                    
                    var file: AVAudioFile!
                    
                    do {
                        try file = AVAudioFile(forReading: (filePath)) //read audio file from local storage
                        print("FILE LENGTH: \(file.length)")
                        print("FILE FORMAT: \(file.fileFormat)")
                        print("FILE PROCESSING FORMAT: \(file.processingFormat)")
                        print("FILE FRAME POSITION: \(file.framePosition)")
                        
                        if let cell: TrackCell = self.collectionView.cellForItem(at: indexPath) as? TrackCell {
                            let equalizer = AVAudioUnitEQ(numberOfBands: 4) //initialize eq
                            self.setupEQ(equalizer: equalizer) //setup new eq
                            self.audioPlayers.remove(at: indexPath.row) //remove audio player at index
                            self.audioPlayers.insert(cell.audioPlayer, at: indexPath.row) //replace with the cells audio player
                            print("AUDIO PLAYER FOR CELL: \(String(describing: cell.audioPlayer))")
                            self.equalizers.remove(at: indexPath.row) //remove equalizer at index
                            self.equalizers.insert(equalizer, at: indexPath.row) //replace with new eq
                            self.audioEngine.attach(cell.audioPlayer!) //attach audio player to audio engine
                            self.audioEngine.attach(equalizer) //attach eq to audio engine
                            self.audioEngine.connect(cell.audioPlayer!, to: equalizer, format: nil) //route audio player to eq
                            self.audioEngine.connect(equalizer, to: self.mixer, format: nil) //route eq to global mixer
                        }
                        
                        
                        self.filesArray.remove(at: indexPath.row) //remove file at index
                        self.filesArray.insert(file, at: indexPath.row) //replace with file at index
                        if let cell: TrackCell = self.collectionView.cellForItem(at: indexPath) as? TrackCell {
                            cell.buttonRemove.isEnabled = true
                            cell.buttonRemove.alpha = 1.0
                            cell.importLight.backgroundColor = .blue
                            cell.buttonImport.isEnabled = false
                            cell.buttonImport.alpha = 0.5
                            cell.audioPlayer?.pan = self.tracks[indexPath.row].pan! //set audio players pan for cell
                            cell.audioPlayer?.volume = self.tracks[indexPath.row].volume! //set audio players volume for cell
                        }
                    } catch let error {
                        self.errorMessage(title: "Error", message: "Could not convert audio files: \(error.localizedDescription)")
                    }
                }
            }
        }
    }
    
    //MARK: DISPATCH GROUP FETCH AUDIO
    
    func dispatchFetchAudio() {
        //This is where we use group dispatch to fetch each audio file at a time to limit issues happening.
        
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 0, section: 0))
            print("fetched 1")
            self.dispatchGroup.leave() //first audio file fetched
        }
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 1, section: 0))
            print("fetched 2")
            self.dispatchGroup.leave() //second audio file fetched
        }
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 2, section: 0))
            print("fetched 3")
            self.dispatchGroup.leave() //third...
        }
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 3, section: 0))
            print("fetched 4")
            self.dispatchGroup.leave()
        }
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 4, section: 0))
            print("fetched 5")
            self.dispatchGroup.leave()
        }
        self.dispatchGroup.enter()
        self.queue.async {
            sleep(1)
            self.fetchAudioFile(indexPath: IndexPath(row: 5, section: 0))
            print("fetched 6")
            sleep(1)
            self.dispatchGroup.leave()
        }
        
        self.dispatchGroup.notify(queue: self.queue) {
            print("Fetched")
            DispatchQueue.main.async {
                //enable everything
                self.goBackToStartButton.isEnabled = true
                self.playButton.isEnabled = true
                self.goBackToStartButton.alpha = 1.0
                self.playButton.alpha = 1.0
                self.view.isUserInteractionEnabled = true
                self.view.alpha = 1.0
                self.loadingProjectIndicator.stopAnimating()
                self.loadingProjectLabel.isHidden = true
                self.trackName.isHidden = false
                self.checkSoloForAllTracks()
                self.scheduleFilesToStart()
            }
        }
    }
    
}
