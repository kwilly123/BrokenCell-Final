//
//  ReadEQData.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-30.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import Firebase

extension TracksViewController {
    
    //MARK: READ EQ DATA
    
    func readEQData(indexPath: IndexPath) {
        DispatchQueue.global(qos: .background).async {
            self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(self.projectKey!).child("tracks").child("track\(indexPath.row)").observeSingleEvent(of: .value) { (snapshot) in //read eq values within specified index
                if let snapshots = snapshot.children.allObjects as? [DataSnapshot] { //get all objects
                    for snap in snapshots {
                        self.values.append(snap.value) //insert into an array so we can easily access it
                    }
                    let freq1 = (self.values[0] as? Float) ?? 20 //we access first 8 values which are all related to EQ
                    let freq2 = (self.values[1] as? Float) ?? 401
                    let freq3 = (self.values[2] as? Float) ?? 2001
                    let freq4 = (self.values[3] as? Float) ?? 8001
                    let gain1 = (self.values[4] as? Float) ?? 0
                    let gain2 = (self.values[5] as? Float) ?? 0
                    let gain3 = (self.values[6] as? Float) ?? 0
                    let gain4 = (self.values[7] as? Float) ?? 0
                    DispatchQueue.main.async {
                        self.equalizers[indexPath.row]?.bands[0].frequency = freq1 //1 assign each eq value corresponding
                        let angle = CGFloat(((freq1 - 20) / (400 - 20)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965) //1
                        self.knob1.renderer.setPointerAngle(angle) //1
                        self.knob1ValueLabel.text = "\(Int(freq1))" //1
                        self.equalizers[indexPath.row]?.bands[1].frequency = freq2 //2
                        self.knob2.renderer.setPointerAngle(CGFloat(((freq2 - 401) / (2000 - 401)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //2
                        self.knob2ValueLabel.text = "\(Int(freq2))" //2
                        self.equalizers[indexPath.row]?.bands[2].frequency = freq3 //3
                        self.knob3.renderer.setPointerAngle(CGFloat(((freq3 - 2001) / (8000 - 2001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //3
                        self.knob3ValueLabel.text = "\(Int(freq3))" //3
                        self.equalizers[indexPath.row]?.bands[3].frequency = freq4 //4
                        self.knob4.renderer.setPointerAngle(CGFloat(((freq4 - 8001) / (20000 - 8001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //4
                        self.knob4ValueLabel.text = "\(Int(freq4))" //4
                        self.equalizers[indexPath.row]?.bands[0].gain = gain1 //5
                        self.knob5.renderer.setPointerAngle(CGFloat(((gain1 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //5
                        self.knob5ValueLabel.text = "\(Int(gain1))" //5
                        self.equalizers[indexPath.row]?.bands[1].gain = gain2 //6
                        self.knob6.renderer.setPointerAngle(CGFloat(((gain2 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //6
                        self.knob6ValueLabel.text = "\(Int(gain2))" //6
                        self.equalizers[indexPath.row]?.bands[2].gain = gain3 //7
                        self.knob7.renderer.setPointerAngle(CGFloat(((gain3 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //7
                        self.knob7ValueLabel.text = "\(Int(gain3))" //7
                        self.equalizers[indexPath.row]?.bands[3].gain = gain4 //8
                        self.knob8.renderer.setPointerAngle(CGFloat(((gain4 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965)) //8
                        self.knob8ValueLabel.text = "\(Int(gain4))" //8
                    }
                }
            }
        }
    }
}
