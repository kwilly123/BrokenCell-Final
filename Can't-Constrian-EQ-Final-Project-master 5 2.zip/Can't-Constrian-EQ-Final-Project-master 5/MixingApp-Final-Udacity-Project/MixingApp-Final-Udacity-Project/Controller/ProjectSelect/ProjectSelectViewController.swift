//
//  TableViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-11.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import Firebase
import AVFoundation

class ProjectSelectViewController: UITableViewController {
    
    var ref: DatabaseReference!
    
    var sendRef: DatabaseReference!
    
    var projectIndex: IndexPath!
    
    var userID: String?
    
    let currentDateTime = Date()
    let formatter = DateFormatter()
    
    var projects: [Project] = []
    
    var tracks = [Track]()
    
    var projectKeys: [String] = []
    var selectedKey: String?
    
    //MARK: VIEWWILLAPPEAR
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ref = Database.database().reference()
        fetchProject()
    }
    
    //MARK: VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK: ADD NEW PROJECT
    
    @IBAction func addProjectTapped(_ sender: Any) {
        let nameProjectAlert = UIAlertController(title: "Project Name", message: "What would you like to name your project?", preferredStyle: .alert)
        nameProjectAlert.addTextField { (textfield: UITextField!) in
            textfield.placeholder = "Project Name"
        }
        nameProjectAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction!) in
            let textField = nameProjectAlert.textFields![0]
            let project = Project()
            project.projectName = textField.text
            self.formatter.timeStyle = .medium
            self.formatter.dateStyle = .medium
            let date = Date()
            project.creationDate = self.formatter.string(from: date)
            
            self.tracks = []
            
            for _ in 0...5 {
                let track = Track()
                track.volume = 0.5 //set initial value for each when creating a new project
                track.volumeSlider = 0.5
                track.pan = 0
                track.mute = false
                track.solo = false
                let eq = EQ()
                eq.freq1 = 20
                eq.freq2 = 401
                eq.freq3 = 2001
                eq.freq4 = 8001
                eq.gain1 = 0
                eq.gain2 = 0
                eq.gain3 = 0
                eq.gain4 = 0
                track.eq = eq
                self.tracks.append(track)
                print("track attached")
            }
            
            project.tracks = self.tracks
            
            let projectRefs = self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").childByAutoId() //write a new project to database
            projectRefs.updateChildValues(["project_name": project.projectName ?? ""])
            projectRefs.updateChildValues(["creation_date": project.creationDate ?? ""])
            let trackRefs = projectRefs.child("tracks")
            self.sendRef = trackRefs
            for i in 0...5 {
                let trackRef = trackRefs.child("track\(i)") //iterate through each track
                trackRef.updateChildValues(["volume": project.tracks![i].volume ?? 0])
                trackRef.updateChildValues(["volume_slider": project.tracks![i].volumeSlider ?? 0])
                trackRef.updateChildValues(["pan": project.tracks![i].pan ?? 0])
                trackRef.updateChildValues(["mute": project.tracks![i].mute ?? 0])
                trackRef.updateChildValues(["solo": project.tracks![i].solo ?? 0])
                trackRef.updateChildValues(["freq1": project.tracks![i].eq?.freq1 ?? 20])
                trackRef.updateChildValues(["freq2": project.tracks![i].eq?.freq2 ?? 401])
                trackRef.updateChildValues(["freq3": project.tracks![i].eq?.freq3 ?? 2001])
                trackRef.updateChildValues(["freq4": project.tracks![i].eq?.freq4 ?? 8000])
                trackRef.updateChildValues(["gain1": project.tracks![i].eq?.gain1 ?? 0])
                trackRef.updateChildValues(["gain2": project.tracks![i].eq?.gain2 ?? 0])
                trackRef.updateChildValues(["gain3": project.tracks![i].eq?.gain3 ?? 0])
                trackRef.updateChildValues(["gain4": project.tracks![i].eq?.gain4 ?? 0])
                print("updated \(i)")
            }
        }))
        nameProjectAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(nameProjectAlert, animated: true, completion: nil)
    }
    
    // MARK: - Table view data source
    
    //MARK: NUMBER OF SECTIONS
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //MARK: NUMBER OF ROWS
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return projects.count
    }
    
    //MARK: CELL FOR ROW
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "project", for: indexPath) as! ProjectCell
        var project = Project()
        
        project = projects[indexPath.row]
        
        cell.projectNameLabel.text = project.projectName
        cell.creationDateLabel.text = project.creationDate
        
        return cell
    }
    
    //MARK: DID SELECT ROW
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedKey = projectKeys[indexPath.row]
        projectIndex = indexPath
        performSegue(withIdentifier: "GoToProject", sender: nil)
    }
    
    //MARK: HEIGHT FOR ROW
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    //MARK: PREPARE
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is TracksViewController {
            let projectVC = segue.destination as? TracksViewController
            projectVC?.userID = userID
            projectVC?.projectKey = selectedKey
            print(projectVC?.projectKey ?? "")
            projectVC?.tracks = projects[projectIndex.row].tracks!
        }
    }
    
}
