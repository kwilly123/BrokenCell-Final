//
//  ViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-03-27.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices
import Firebase

class TracksViewController: UIViewController {
    
    var userID: String?
    
    var projectKey: String?
    
    var tracks = [Track]()
    
    var ref: DatabaseReference!
    
//    var projectRef: DatabaseReference!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var goBackToStartButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    
    @IBOutlet weak var progressLoading: UIProgressView!
    
    @IBOutlet weak var uploadingAudioLabel: UILabel!
    
    @IBOutlet weak var loadingProjectIndicator: UIActivityIndicatorView!
    @IBOutlet weak var loadingProjectLabel: UILabel!
    
    @IBOutlet weak var eqcompView: UIView!
    @IBOutlet weak var knob1: Knob!
    @IBOutlet weak var knob2: Knob!
    @IBOutlet weak var knob3: Knob!
    @IBOutlet weak var knob4: Knob!
    @IBOutlet weak var knob5: Knob!
    @IBOutlet weak var knob6: Knob!
    @IBOutlet weak var knob7: Knob!
    @IBOutlet weak var knob8: Knob!
    
    @IBOutlet weak var knob1ValueLabel: UILabel!
    @IBOutlet weak var knob2ValueLabel: UILabel!
    @IBOutlet weak var knob3ValueLabel: UILabel!
    @IBOutlet weak var knob4ValueLabel: UILabel!
    @IBOutlet weak var knob5ValueLabel: UILabel!
    @IBOutlet weak var knob6ValueLabel: UILabel!
    @IBOutlet weak var knob7ValueLabel: UILabel!
    @IBOutlet weak var knob8ValueLabel: UILabel!
    
    @IBOutlet weak var trackName: UILabel!
    
    let queue = DispatchQueue(label: "Serial queue")
    
    var knobs: [Knob] = []
    
    var audioEngine: AVAudioEngine = AVAudioEngine()
    var mixer: AVAudioMixerNode = AVAudioMixerNode()
    var audioPlayers = [AVAudioPlayerNode?](repeating: nil, count: 6)
    var equalizers = [AVAudioUnitEQ?](repeating: nil, count: 6)
    
    var soloIndexPath = [IndexPath?](repeating: nil, count: 6)
    
    var startSeconds: Int64!
    
    var filesArray = [AVAudioFile?](repeating: nil, count: 6)
    
    let dispatchGroup = DispatchGroup()
    
    //MARK: VIEWWILLAPPEAR
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        progressLoading.tintColor = .red
        progressLoading.progress = 0
        goBackToStartButton.isEnabled = false //disable go back to start button
        playButton.isEnabled = false //disable play button
        view.isUserInteractionEnabled = false //disable view
        view.alpha = 0.5 //tint view
        trackName.isHidden = true
        view.sendSubviewToBack(collectionView) //send collection view back behind the loading activity indicator
        view.bringSubviewToFront(loadingProjectIndicator) //bring activity indicator forward
        view.bringSubviewToFront(loadingProjectLabel)
        loadingProjectIndicator.startAnimating()
        eqcompView.isUserInteractionEnabled = false
        eqcompView.alpha = 0.5
        setupAudioEngine()
    }
    
    //MARK: VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        print("PROJECT KEY: \(projectKey ?? "")")
        
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        setupCollection()
        
        setupEQView()
        
        setupKnobs()
        knobs = [knob1, knob2, knob3, knob4, knob5, knob6, knob7, knob8]
        
        dispatchFetchAudio()
    }
    
    var index: IndexPath!
    
    //MARK: COLLECTION VIEW SETUP
    
    func setupCollection() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = flowLayout
        
        collectionView.register(UINib(nibName: "TrackCell", bundle: nil), forCellWithReuseIdentifier: "track")
        
        flowLayout.estimatedItemSize = CGSize(width: view.frame.width / 3, height: collectionView.frame.height / 2)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(cellTapped(_:)))
        collectionView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    //MARK: SETUP EQVIEW
    
    func setupEQView() {
        eqcompView.layer.borderWidth = 5
        eqcompView.layer.cornerRadius = 5
        eqcompView.layer.borderColor = UIColor.darkGray.cgColor
    }
    
    //MARK: CELL TAPPED
    
    var values = [Any?]() //for readEQData
    
    @objc func cellTapped(_ sender: UITapGestureRecognizer) {
        eqcompView.isUserInteractionEnabled = true
        eqcompView.alpha = 1.0
        let pointInCollectionView = sender.location(in: collectionView)
        let indexPath = collectionView.indexPathForItem(at: pointInCollectionView)
        index = indexPath
        print(index ?? 0)
        if let indexPath = indexPath {
            trackName.text = "Track \(indexPath.row + 1)"
            values = []
            readEQData(indexPath: indexPath)
        } else {
            eqcompView.isUserInteractionEnabled = false
            eqcompView.alpha = 0.5
            trackName.text = "Select a Track"
        }
    }
    
    @IBAction func knob1ValueChanged(_ sender: Any) {
        updateEQFrequencyByKnob(knob: knob1, value: "freq1", band: 0)
        knob1ValueLabel.text = "\(Int(knob1.value))" //update value to label
    }
    
    @IBAction func knob2ValueChanged(_ sender: Any) {
        updateEQFrequencyByKnob(knob: knob2, value: "freq2", band: 1)
        knob2ValueLabel.text = "\(Int(knob2.value))"
    }
    
    @IBAction func knob3ValueChanged(_ sender: Any) {
        updateEQFrequencyByKnob(knob: knob3, value: "freq3", band: 2)
        knob3ValueLabel.text = "\(Int(knob3.value))"
    }
    
    @IBAction func knob4ValueChanged(_ sender: Any) {
        updateEQFrequencyByKnob(knob: knob4, value: "freq4", band: 3)
        knob4ValueLabel.text = "\(Int(knob4.value))"
    }
    
    
    @IBAction func knob5ValueChanged(_ sender: Any) {
        updateEQGainByKnob(knob: knob5, value: "gain1", band: 0)
        knob5ValueLabel.text = "\(Int(knob5.value))"
    }
    
    
    @IBAction func knob6ValueChanged(_ sender: Any) {
        updateEQGainByKnob(knob: knob6, value: "gain2", band: 1)
        knob6ValueLabel.text = "\(Int(knob6.value))"
    }
    
    
    @IBAction func knob7ValueChanged(_ sender: Any) {
        updateEQGainByKnob(knob: knob7, value: "gain3", band: 2)
        knob7ValueLabel.text = "\(Int(knob7.value))"
    }
    
    
    @IBAction func knob8ValueChanged(_ sender: Any) {
        updateEQGainByKnob(knob: knob8, value: "gain4", band: 3)
        knob8ValueLabel.text = "\(Int(knob8.value))" //update value to label
    }
    
    func updateEQFrequencyByKnob(knob: Knob, value: String, band: Int) {
        guard let index = index else { return } //make sure the index is there
        self.equalizers[self.index.row]?.bands[band].frequency = knob.value //modify frequency to knob
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(index.row)").updateChildValues(["\(value)" : knob.value]) //update value to firebase
    }
    
    func updateEQGainByKnob(knob: Knob, value: String, band: Int) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[band].gain = knob.value
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(index.row)").updateChildValues(["\(value)" : knob.value])
    }
    
    func playTracks() {
        DispatchQueue.global(qos: .background).async {
            for audioPlayer in self.audioPlayers { //will play all audio players at the same time
                audioPlayer?.play(at: nil)
                print("Playing")
            }
        }
    }
    
    @IBAction func playButtonTapped(_ sender: Any) {
        playButton.isSelected = !playButton.isSelected
        if playButton.isSelected {
            do {
                try audioEngine.start()
                let sampleTime = audioEngine.outputNode.lastRenderTime?.sampleTime
                let sampleRate = audioEngine.outputNode.outputFormat(forBus: 0).sampleRate
                startSeconds =  sampleTime! / AVAudioFramePosition(sampleRate)
                print(startSeconds ?? 0) //get start time of audio engine, not really important but if i were to go further with the app to create a timeline session like Logic Pro X or Pro Tools, etc...
            } catch let error {
                errorMessage(title: "Error", message: "Could not start audio engine: \(error.localizedDescription)")
            }
            playTracks()
            playButton.setBackgroundImage(UIImage(systemName: "stop"), for: .normal)
            playButton.isSelected = true
        } else {
            playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
            playButton.isSelected = false
            audioEngine.pause()
            
            for audioPlayer in audioPlayers {
                audioPlayer?.pause()
            }
        }
    }
    
    @IBAction func goBackButtonTapped(_ sender: Any) {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.stop()
            do {
                try self.audioEngine.start()
            } catch let error {
                self.errorMessage(title: "Error", message: "Could not restart audio engine: \(error.localizedDescription)")
            }
            for audioPlayer in self.audioPlayers {
                audioPlayer?.stop()
            }
            self.scheduleFilesToStart()
            DispatchQueue.main.async {
                self.playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
                self.playButton.isSelected = false
            }
        }
    }
    
}
