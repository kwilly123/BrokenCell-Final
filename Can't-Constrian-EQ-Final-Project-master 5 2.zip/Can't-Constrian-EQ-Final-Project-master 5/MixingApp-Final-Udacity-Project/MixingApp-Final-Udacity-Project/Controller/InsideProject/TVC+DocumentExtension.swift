//
//  VC+DocumentExtension.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-06.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import Firebase

extension TracksViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        self.attachFiles(audioFile: urls[0]) //imported audio url gets sent through here
        
        let uploadRef = Storage.storage().reference().child(userID!).child(projectKey!).child("audiofiles").child("track\(index.row)").child("audio\(index.row).mp3")
        guard let audioData = try? Data(contentsOf: urls[0]) else { return }
        let uploadMetadata = StorageMetadata.init()
        uploadMetadata.contentType = "audio/mp3" //user can only upload mp3 files
        
        DispatchQueue.global(qos: .background).async {
            let taskReference = uploadRef.putData(audioData, metadata: uploadMetadata) { (downloadMetadata, error) in
                if let error = error {
                    self.errorMessage(title: "Error", message: "Error uploading data: \(error.localizedDescription)")
                    print(error.localizedDescription)
                    return
                }
                print("METADATA: \(String(describing: downloadMetadata))") //display meta data if successfully uploaded
                self.uploadingAudioLabel.text = "Upload Complete!"
            }
            
            DispatchQueue.main.async {
                self.uploadingAudioLabel.isHidden = false
            }
            
            taskReference.observe(.progress) { (snapshot) in //observe progress of upload
                guard let progress = snapshot.progress?.fractionCompleted else { return }
                print("You are \(progress) complete!")
                DispatchQueue.main.async {
                    self.uploadingAudioLabel.text = "Uploading audio to database, do not close app: \(round(progress * 100))%"
                    self.progressLoading.progress = Float(progress) //track progress of upload
                }
            }
        }
        
        
        for cell: TrackCell in collectionView!.visibleCells as! [TrackCell] {
            cell.audioPlayer?.stop() //stop all audio players
        }
        
        DispatchQueue.main.async {
            self.playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
            self.playButton.isSelected = false
        }
        
        print("\(urls[0])")
        if let cell = collectionView.cellForItem(at: index) as? TrackCell {
            self.audioPlayers.remove(at: index.row) //remove the audio player at index
            self.audioPlayers.insert(cell.audioPlayer, at: index.row) //insert a new audio player
            let equalizer = AVAudioUnitEQ(numberOfBands: 4) //initialize eq with 4 bands
            self.setupEQ(equalizer: equalizer) //setup eq parameters with new eq
            self.equalizers.remove(at: index.row) //remove eq from the array at index
            self.equalizers.insert(equalizer, at: index.row) //insert the new eq at index in array
            self.audioEngine.attach(cell.audioPlayer!) //attach the audioplayer from the cell to audio engine
            self.audioEngine.attach(equalizer) //attach the new eq to audio engine
            self.audioEngine.connect(cell.audioPlayer!, to: equalizer, format: nil) //route audio player to eq
            self.audioEngine.connect(equalizer, to: self.mixer, format: nil) //route eq to global mixer
            
            cell.buttonRemove.isEnabled = true
            cell.buttonRemove.alpha = 1.0
            cell.importLight.backgroundColor = .blue
            cell.buttonImport.isEnabled = false
            cell.buttonImport.alpha = 0.5
            self.scheduleFilesToStart()
        }
    }
    
}
