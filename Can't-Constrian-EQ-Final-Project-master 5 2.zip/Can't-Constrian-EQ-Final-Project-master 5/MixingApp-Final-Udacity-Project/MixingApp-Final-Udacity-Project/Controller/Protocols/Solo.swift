//
//  Solo.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Solo {
    
    //MARK: SOLO BUTTON TAPPED
    
    func soloButtonTapped(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was soloed!")
        cell.isMuted = false
        cell.audioPlayer?.volume = cell.volumeSlider.value
        cell.muteButton.tintColor = .clear
        cell.muteButton.backgroundColor = .clear
        cell.muteButton.alpha = 0.7
        cell.muteButton.isEnabled = false
        cell.muteButton.isSelected = false
        soloIndexPath.remove(at: indexPath!.row)
        soloIndexPath.insert(indexPath, at: indexPath!.row)
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["solo" : true]) //update database value for solo on index to true
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : false]) //update the database and make the track not muted if it is
        print("SOLO INDEX: \(soloIndexPath)")
        for item in 0..<collectionView.numberOfItems(inSection: 0) where item != soloIndexPath[item]?.row {
            let indexPaths = IndexPath(item: item, section: 0)
            if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                cell.isMuted = true
                cell.audioPlayer?.volume = 0
                cell.muteButton.tintColor = .muteBlue
                cell.muteButton.backgroundColor = .muteBlue
                cell.muteButton.alpha = 0.7
                cell.muteButton.isEnabled = false
                cell.muteButton.isSelected = false
                self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPaths.row)").updateChildValues(["mute" : true]) //every cell but the cell thats soloed gets muted
            }
        }
    }
    
    //MARK: SOLO BUTTON TAPPED AGAIN
    
    func soloButtonTappedAgain(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was unsoloed!")
        cell.isMuted = true
        cell.audioPlayer?.volume = 0
        cell.muteButton.tintColor = .muteBlue
        cell.muteButton.backgroundColor = .muteBlue
        cell.muteButton.alpha = 0.7
        cell.muteButton.isEnabled = false
        soloIndexPath.remove(at: indexPath!.row)
        soloIndexPath.insert(nil, at: indexPath!.row)
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["solo" : false]) //update database value for solo on index to false
        self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : true]) //update the database and make the track muted
        print("SOLO INDEX: \(soloIndexPath)")
        if soloIndexPath.allEqualTo(value: nil) { //right here checks if the solo array is all nil, if it is, it will clear all mutes
            for item in 0..<collectionView.numberOfItems(inSection: 0) {
                let indexPaths = IndexPath(item: item, section: 0)
                if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                    cell.isMuted = false
                    cell.audioPlayer?.volume = cell.volumeSlider.value
                    cell.muteButton.tintColor = .clear
                    cell.muteButton.backgroundColor = .clear
                    cell.muteButton.alpha = 1.0
                    cell.muteButton.isEnabled = true
                    self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPaths.row)").updateChildValues(["mute" : false]) //every cell gets unmuted
                }
            }
        }
    }
    
}

extension Array where Element: Equatable {
    func allEqualTo(value: Element) -> Bool { //use this to clear all the mutes when the solo is unactivated
        return !contains { $0 != value}
    }
}

extension TracksViewController {
    
    //MARK: CHECK SOLO FOR COLLECTION
    
    func checkSoloTrack(cell: TrackCell, indexPath: IndexPath) {
        if cell.isSoloed == true {
            cell.soloButton.backgroundColor = .soloYellow
            cell.soloButton.tintColor = .soloYellow
            cell.soloButton.isSelected = true
            soloIndexPath.remove(at: indexPath.row)
            soloIndexPath.insert(indexPath, at: indexPath.row)
        }
    }
    
    func checkSoloForAllTracks() {
        if soloIndexPath.allEqualTo(value: nil) {
            for item in 0..<collectionView.numberOfItems(inSection: 0) {
                let indexPaths = IndexPath(item: item, section: 0)
                if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                    cell.isMuted = false
                    cell.audioPlayer?.volume = cell.volumeSlider.value
                    cell.muteButton.tintColor = .clear
                    cell.muteButton.backgroundColor = .clear
                    cell.muteButton.alpha = 1.0
                    cell.muteButton.isEnabled = true
                    self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPaths.row)").updateChildValues(["mute" : false]) //every cell gets unmuted
                }
            }
        } else {
            for item in 0..<collectionView.numberOfItems(inSection: 0) where item != soloIndexPath[item]?.row {
                let indexPaths = IndexPath(item: item, section: 0)
                if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                    cell.isMuted = true
                    cell.audioPlayer?.volume = 0
                    cell.muteButton.tintColor = .muteBlue
                    cell.muteButton.backgroundColor = .muteBlue
                    cell.muteButton.alpha = 0.7
                    cell.muteButton.isEnabled = false
                    cell.muteButton.isSelected = false
                    self.ref.database.reference().child("user_profiles").child(self.userID!).child("projects").child(projectKey!).child("tracks").child("track\(indexPaths.row)").updateChildValues(["mute" : true]) //every cell but the cell thats soloed gets muted
                }
            }
        }
    }
}
