//
//  ScheduleAudioFiles.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import AVFoundation

extension TracksViewController {
    
    //MARK: SCHEDULE FILES TO START
    
    func scheduleFilesToStart() {
        DispatchQueue.global(qos: .background).async {
            for (index, audioPlayer) in self.audioPlayers.enumerated() { //iterate through each audio player
                if let file = self.filesArray[index] {
                    audioPlayer?.scheduleFile(file, at: nil, completionHandler: nil) //and schedule each file to the corresponding audio player
                    print(file)
                } else {
                    print("Audio File nil") //if there is no audio file
                }
            }
        }
    }
    
    func attachFiles(audioFile: URL) {
        let fileURL = audioFile
        
        var file: AVAudioFile!
        
        do {
            try file = AVAudioFile(forReading: (fileURL.absoluteURL))
            print(file.length)
            filesArray.remove(at: self.index.row)
            filesArray.insert(file, at: self.index.row)
            print("FILES: \(String(describing: filesArray))")
            scheduleFilesToStart()
        } catch let error {
            errorMessage(title: "Error", message: "Could not attach audio file: \(error.localizedDescription)")
        }
    }
    
}
