//
//  CustomColors.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-30.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    static let muteBlue = UIColor(red: 81/255, green: 138/255, blue: 179/255, alpha: 1.0)
    static let soloYellow = UIColor(red: 255/255, green: 198/255, blue: 0/255, alpha: 1.0)
}
