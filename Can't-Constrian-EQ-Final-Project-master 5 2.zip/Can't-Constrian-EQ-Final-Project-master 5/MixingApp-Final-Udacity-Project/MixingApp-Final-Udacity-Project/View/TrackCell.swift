//
//  TrackCell.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-03-28.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import VerticalSlider
import AVFoundation

//Protocols For Each Cell
protocol Mute: AnyObject {
    func muteButtonTapped(cell: TrackCell)
    func muteButtonTappedAgain(cell: TrackCell)
}

protocol Solo: AnyObject {
    func soloButtonTapped(cell: TrackCell)
    func soloButtonTappedAgain(cell: TrackCell)
}

protocol Tracks: AnyObject {
    func importTrack(cell: TrackCell)
    func removeTrack(cell: TrackCell)
}

protocol Volume: AnyObject {
    func changeVolume(cell: TrackCell, volume: Float)
    func changeSliderVolume(cell: TrackCell, volume: Float)
}

protocol Pan: AnyObject {
    func changePan(cell: TrackCell, pan: Float)
}

class TrackCell: UICollectionViewCell {
    
    var back: UIView!
    var flip = true
    
    var audioPlayer: AVAudioPlayerNode?
    var isMuted = false
    var isSoloed = false
    
    @IBOutlet weak var volumeSlider: VerticalSlider!
    @IBOutlet weak var knob: Knob!
    @IBOutlet weak var muteButton: UIButton!
    @IBOutlet weak var soloButton: UIButton!
    @IBOutlet weak var panValueLabel: UILabel!
    @IBOutlet weak var importLight: UIView!
    @IBOutlet weak var trackLabel: UILabel!
    
    var buttonImport: UIButton!
    var buttonRemove: UIButton!
    var buttonGoBack: UIButton!
    
    weak var muteDelegate: Mute?
    weak var soloDelegate: Solo?
    weak var trackDelegate: Tracks?
    weak var volumeDelegate: Volume?
    weak var panDelegate: Pan?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
//        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        
        audioPlayer = AVAudioPlayerNode() //initialize audio player for cell
        
        setupPanLabel()
        setupMuteSoloButton()
        setupVolumeSlider()
        setupImportLight()
        setupTrackLabelGesture()
        createBackView()
    }
    
    func setupPanLabel() {
        panValueLabel.text = "0" //initial value is 0
        knob.bringSubviewToFront(panValueLabel) //bring pan label forward so its not hiding behind the knob view
    }
    
    func setupMuteSoloButton() {
        muteButton.layer.borderColor = UIColor.white.cgColor
        muteButton.layer.borderWidth = 2
        soloButton.layer.borderColor = UIColor.white.cgColor
        soloButton.layer.borderWidth = 2
    }
    
    func setupVolumeSlider() {
        volumeSlider.tintColor = .green
        volumeSlider.value = 0.5
        audioPlayer?.volume = volumeSlider.value //set audio players volume to the volume slider
    }
    
    func setupImportLight() {
        importLight.layer.borderColor = UIColor.gray.cgColor
        importLight.layer.borderWidth = 1
    }
    
    func setupTrackLabelGesture() {
        let longTap = UILongPressGestureRecognizer(target: self, action: #selector(handleLongTap(sender:)))
        trackLabel.addGestureRecognizer(longTap)
        trackLabel.isUserInteractionEnabled = true
    }
    
    @objc func handleLongTap(sender: UITapGestureRecognizer) {
        print("long tapped")
        if flip {
            contentView.addSubview(back)
            UIView.transition(from: contentView, to: back, duration: 1, options: UIView.AnimationOptions.transitionFlipFromLeft, completion: nil)
            flip = false
        } else {
            UIView.transition(from: back, to: contentView, duration: 1, options: UIView.AnimationOptions.transitionFlipFromLeft, completion: nil)
            flip = true
        }
    }
    
    //MARK: IMPORT TRACK BUTTON SETUP
    
    fileprivate func setupImportTrackButton() {
        buttonImport = UIButton(type: .system)
        buttonImport.frame = CGRect(x: 0, y: 0, width: 70, height: 45)
        buttonImport.setTitle("Import\nTrack", for: .normal)
        buttonImport.setTitleColor(.white, for: .normal)
        buttonImport.titleLabel?.textAlignment = .center
        buttonImport.titleLabel?.numberOfLines = 0
        buttonImport.layer.borderColor = UIColor.white.cgColor
        buttonImport.layer.borderWidth = 2
        buttonImport.center.x = back.center.x
        back.addSubview(buttonImport)
        buttonImport.addTarget(self, action: #selector(importTrack), for: .touchUpInside)
    }
    
    @objc func importTrack() {
        trackDelegate?.importTrack(cell: self)
    }
    
    //MARK: REMOVE TRACK BUTTON SETUP
    
    fileprivate func setupRemoveTrackButton() {
        buttonRemove = UIButton(type: .system)
        buttonRemove.frame = CGRect(x: 0, y: 50, width: 70, height: 45)
        buttonRemove.setTitle("Remove\nTrack", for: .normal)
        buttonRemove.setTitleColor(.white, for: .normal)
        buttonRemove.titleLabel?.textAlignment = .center
        buttonRemove.titleLabel?.numberOfLines = 0
        buttonRemove.layer.borderColor = UIColor.white.cgColor
        buttonRemove.layer.borderWidth = 2
        buttonRemove.center.x = back.center.x
        buttonRemove.isEnabled = false
        buttonRemove.alpha = 0.5
        back.addSubview(buttonRemove)
        buttonRemove.addTarget(self, action: #selector(removeTrack), for: .touchUpInside)
    }
    
    @objc func removeTrack() {
        trackDelegate?.removeTrack(cell: self)
    }
    
    //MARK: GO BACK BUTTON SETUP
    
    fileprivate func setupGoBackButton() {
        buttonGoBack = UIButton(type: .system)
        buttonGoBack.frame = CGRect(x: 0, y: 100, width: 70, height: 45)
        buttonGoBack.setTitle("Go\nBack", for: .normal)
        buttonGoBack.setTitleColor(.white, for: .normal)
        buttonGoBack.titleLabel?.textAlignment = .center
        buttonGoBack.titleLabel?.numberOfLines = 0
        buttonGoBack.layer.borderColor = UIColor.white.cgColor
        buttonGoBack.layer.borderWidth = 2
        buttonGoBack.center.x = back.center.x
        back.addSubview(buttonGoBack)
        buttonGoBack.addTarget(self, action: #selector(handleLongTap(sender:)), for: .touchUpInside)
    }
    
    //MARK: FLIPPED CELL BACK VIEW
    
    func createBackView() {
        back = UIView(frame: self.frame)
        back.backgroundColor = .black
        setupImportTrackButton()
        setupRemoveTrackButton()
        setupGoBackButton()
    }
    
    //MARK: MUTE BUTTON TAPPED
    
    @IBAction func muteButtonTapped(_ sender: Any) {
        if isMuted == true { //isMuted is decided in the protocols
            muteButton.isSelected = false
            isMuted = false
            muteDelegate?.muteButtonTappedAgain(cell: self)
            audioPlayer?.volume = volumeSlider.value
            muteButton.backgroundColor = .clear
            muteButton.tintColor = .clear
            volumeDelegate?.changeVolume(cell: self, volume: audioPlayer?.volume ?? 0)
            volumeDelegate?.changeSliderVolume(cell: self, volume: volumeSlider.value)
        } else {
            muteButton.isSelected = true
            isMuted = true
            muteDelegate?.muteButtonTapped(cell: self)
            audioPlayer?.volume = 0
            muteButton.backgroundColor = .muteBlue
            muteButton.tintColor = .muteBlue
            volumeDelegate?.changeVolume(cell: self, volume: audioPlayer?.volume ?? 0)
            volumeDelegate?.changeSliderVolume(cell: self, volume: volumeSlider.value)
        }
    }
    
    //MARK: SOLO BUTTON TAPPED
    
    @IBAction func soloButtonTapped(_ sender: Any) {
        soloButton.isSelected = !soloButton.isSelected
        if soloButton.isSelected {
            soloDelegate?.soloButtonTapped(cell: self)
            soloButton.backgroundColor = .soloYellow
            soloButton.tintColor = .soloYellow
        } else {
            soloDelegate?.soloButtonTappedAgain(cell: self)
            soloButton.backgroundColor = .clear
            soloButton.tintColor = .clear
        }
    }
    
    //MARK: VOLUME SLIDER CHANGED
    
    @IBAction func volumeSliderValueChanged(_ sender: Any) {
        if isMuted { //if isMuted is true set the volume for the track to 0 but keep the Volume Slider in the same position
            audioPlayer?.volume = 0
            volumeDelegate?.changeVolume(cell: self, volume: audioPlayer?.volume ?? 0)
            volumeDelegate?.changeSliderVolume(cell: self, volume: volumeSlider.value)
        } else {
            audioPlayer?.volume = volumeSlider.value
            volumeDelegate?.changeVolume(cell: self, volume: audioPlayer?.volume ?? 0)
            volumeDelegate?.changeSliderVolume(cell: self, volume: audioPlayer?.volume ?? 0)
        }
    }
    
    //MARK: PAN KNOB VALUE CHANGED
    
    @IBAction func knobValueChanged(_ sender: Any) {
        let newValue = Int(knob.value * 100) //to get a value of 100 instead of 1.0 for the label
        panValueLabel.text = "\(newValue)"
        audioPlayer?.pan = knob.value //set audioplayer pan
        panDelegate?.changePan(cell: self, pan: audioPlayer?.pan ?? 0)
    }
    
}
